$(document).ready(function(){
    $(".homepage-slides").owlCarousel({
        items: 1,
        nav: false,
        dots: true,
        loop: true,
        autoplay: false
        

    });
});
